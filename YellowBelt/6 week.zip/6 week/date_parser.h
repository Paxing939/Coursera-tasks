#pragma once

#include "date.h"

Date ParseDate(std::istream &is);
