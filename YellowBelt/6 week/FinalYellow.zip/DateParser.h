#pragma once

#include "Date.h"

Date ParseDate(std::istream &is);
